package com.cg.es.exception;

public class ElectronicProductTypeNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ElectronicProductTypeNotFoundException(String errorMessage) {
		super(errorMessage);
	}


}
