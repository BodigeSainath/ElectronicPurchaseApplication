package com.cg.es.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.es.exception.ManagerNotFoundException;
import com.cg.es.model.CustomerModel;
import com.cg.es.model.ElectronicProductModel;
import com.cg.es.model.ElectronicProductOrderModel;
import com.cg.es.model.ManagerModel;
import com.cg.es.service.CustomerServiceImpl;
import com.cg.es.service.EMParser;
import com.cg.es.service.ElectronicProductServiceImpl;
import com.cg.es.service.IManagerService;

@RestController
@RequestMapping(path="/manager")
public class ManagerAPI {
	@Autowired
	private IManagerService mgrService;
	
	@Autowired
	private ElectronicProductServiceImpl prodService;
	
	@Autowired
	private CustomerServiceImpl cusService;
	
	@Autowired
	private EMParser parser;
	//http://localhost:8080/manager/getallmanagers
	@GetMapping("/getallmanagers")  /* to see all managers list */
	public ResponseEntity<List<ManagerModel>> findAllmanager() {
		return new ResponseEntity<>(mgrService.findAll(), HttpStatus.OK); 
	}
	//http://localhost:8080/manager/getmanager/{managerId}
	@GetMapping("/getmanager/{managerId}")
	public ResponseEntity<ManagerModel> findById(@PathVariable("managerId") Long managerId)throws ManagerNotFoundException {
		ResponseEntity<ManagerModel> response = null;
		System.out.println("find-by-mgrid");
		ManagerModel mgr = mgrService.findById(managerId);
		
		if (mgr == null) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			response = new ResponseEntity<>(mgr, HttpStatus.OK);
		}
		return response;
	}
	//http://localhost:8080/manager/addmanager
	@PostMapping("/addmanager") /* add manager */
	public ResponseEntity<ManagerModel> createManager(@RequestBody ManagerModel mgr) throws ManagerNotFoundException {
		mgr = mgrService.add(mgr);
		return new ResponseEntity<>(mgr, HttpStatus.CREATED);
		
	}
	//http://localhost:8080/manager/deletemanager/{managerId}
	
	@DeleteMapping("/deletemanager/{managerId}") /* delete by id */
	public ResponseEntity<Void> deleteManager(@PathVariable("managerId") Long managerId) {
		ResponseEntity<Void> response = null;
		ManagerModel mgr = mgrService.findById(managerId);
		if (mgr == null) {
			response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			mgrService.deleteById(managerId);
			response = new ResponseEntity<>(HttpStatus.OK);
		}
		return response;
	}
	//http://localhost:8080/manager/updatemanager/{managerId}
	@PutMapping("/updatemanager/{managerId}") /*update by id */
	public ResponseEntity<ManagerModel> updateManager(@RequestBody ManagerModel mgr,@PathVariable("managerId") Long managerId)throws ManagerNotFoundException {
		mgr = mgrService.update(mgr ,mgr.getManagerId());
		return new ResponseEntity<>(mgr, HttpStatus.OK);
	}
	
	
/************************************************************************************************/
	//http://localhost:8080/manager/getallcustomers/{managerId}
	@GetMapping("/getallcustomers/{managerId}")
	public ResponseEntity<List<CustomerModel>> getAllByManagerId(@PathVariable(name = "managerId") Long managerId)throws ManagerNotFoundException {
		ResponseEntity<CustomerModel> response = null;
		List<CustomerModel> manager = mgrService.getAllByManagerId(managerId);

		return new ResponseEntity<>(mgrService.getAllByManagerId(managerId), HttpStatus.OK); 
		
	}
	//http://localhost:8080/manager/getallproducts/{managerId}
	@GetMapping("/getallproducts/{managerId}")
	public ResponseEntity<List<ElectronicProductModel>> showAllByManagerId(@PathVariable(name = "managerId") Long managerId)throws ManagerNotFoundException {
		ResponseEntity<ElectronicProductModel> response = null;
		List<ElectronicProductModel> manager = mgrService.showAllByManagerId(managerId);

		return new ResponseEntity<>(mgrService.showAllByManagerId(managerId), HttpStatus.OK); 
		
	}
	//http://localhost:8080/manager/getallorders/{managerId}
	@GetMapping("/getallorders/{managerId}")
	public ResponseEntity<List<ElectronicProductOrderModel>> findAllByManagerId(@PathVariable(name = "managerId") Long managerId)throws ManagerNotFoundException {
		ResponseEntity<ElectronicProductOrderModel> response = null;
		List<ElectronicProductOrderModel> manager = mgrService.findAllByManagerId(managerId);

		return new ResponseEntity<>(mgrService.findAllByManagerId(managerId), HttpStatus.OK); 
		
	}
	
}