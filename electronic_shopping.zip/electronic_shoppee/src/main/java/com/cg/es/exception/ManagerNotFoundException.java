package com.cg.es.exception;

public class ManagerNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ManagerNotFoundException(String error) {
		// TODO Auto-generated constructor stub
		super(error);
	}
}
