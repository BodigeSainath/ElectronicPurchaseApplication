package com.cg.es.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.es.entity.BasketEntity;
import com.cg.es.entity.CustomerEntity;
import com.cg.es.entity.ElectronicProductEntity;
import com.cg.es.exception.BasketNotFoundException;
import com.cg.es.exception.ManagerNotFoundException;
import com.cg.es.model.BasketModel;
import com.cg.es.model.ElectronicProductModel;
import com.cg.es.model.ManagerModel;
import com.cg.es.repository.BasketRepository;
import com.cg.es.repository.CustomerRepository;
import com.cg.es.repository.ElectronicProductRepository;

@Service											//Implementing all the methods of IBasketService
public class BasketServiceImpl implements IBasketService{
	@Autowired										//inject dependency for Basket
	private BasketRepository basketRepo;
	@Autowired										//inject dependency for ELectronicProduct
	private ElectronicProductRepository elecprodRepo;
	@Autowired										//inject dependency for Customer					
	private CustomerRepository customerRepo;
	@Autowired						
	private EMParser parser;
	
	static final Logger LOGGER = LoggerFactory.getLogger(BasketServiceImpl.class);

	public BasketServiceImpl() {
		
	}

	public BasketServiceImpl(BasketRepository basketRepo, ElectronicProductRepository elecprodRepo, EMParser parser) {
		super();
		this.basketRepo = basketRepo;
		this.elecprodRepo = elecprodRepo;
		this.parser = new EMParser();
	}

	@Override 							//method for adding basket
	public BasketModel add(BasketModel basketModel) throws BasketNotFoundException {
		LOGGER.info("called add() method of basketservice");
		if (basketModel != null) {
			if (basketRepo.existsById(basketModel.getBasketId())) {
				throw new BasketNotFoundException("Basket with Id " + basketModel.getBasketId() + " is exist already");
				} else {
					basketModel = parser.parse(basketRepo.save((parser.parse(basketModel))));
					}
			}
		return basketModel;
		}


	@Override
	public void deleteById(Long BasketId) {
		LOGGER.info("called delete() method of basketservice");
		
		basketRepo.deleteById(BasketId);
		
	}

	@Override									//method for finding by Id
	public BasketModel findById(Long BasketId) {
		LOGGER.info("called findById() method of basketservice");
		
		return parser.parse(basketRepo.findById(BasketId).orElse(null));
	}

	@Override								//method for finding
	public List<BasketModel> findAll() {
		LOGGER.info("called find() method of basketservice");
		
		return basketRepo.findAll().stream().map(parser::parse).collect(Collectors.toList());
	}
	
	@Override									//method for showing list of electronicProduct
	public List<ElectronicProductModel> showAll() {
		return elecprodRepo.findAll().stream().map(parser::parse).collect(Collectors.toList());
	}


	@Override									//method for updating the basket
	public BasketModel update(BasketModel basketModel, Long BasketId) throws BasketNotFoundException {
		LOGGER.info("called update() method of basketservice");
		
		if(basketModel != null) {
			if(!basketRepo.existsById(BasketId)) {
				throw new BasketNotFoundException("no such id");
			}
			basketModel = parser.parse(basketRepo.save(parser.parse(basketModel)));
		}
		return basketModel;
	}
	
	@Override							//method for finding all product by customer id
	public List<BasketModel> findAllByCustomerId(Long customerId){
		LOGGER.info("called findAll() method of basketservice");
		
		Optional<CustomerEntity> customerOptional = customerRepo.findById(customerId);	
		List<BasketEntity> products = customerOptional.get().getBasket();	
		return products.stream().map(parser::parse).collect(Collectors.toList());
	}

}
