package com.cg.es.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.es.entity.CustomerEntity;
import com.cg.es.entity.ElectronicProductOrderEntity;
import com.cg.es.exception.ElectronicProductOrderNotFoundException;
import com.cg.es.model.ElectronicProductOrderModel;
import com.cg.es.repository.CustomerRepository;
import com.cg.es.repository.ElectronicProductOrderRepository;
@Service
public class ElectronicProductOrderServiceImpl implements IElectronicProductOrderService{
	@Autowired									//inject dependency for ELectronicProduct
	private ElectronicProductOrderRepository ordRepo;
	
	@Autowired									//inject dependency for Customer	
	private CustomerRepository customerRepo;
	
	@Autowired									
	private EMParser parser;
	static final Logger LOGGER = LoggerFactory.getLogger(ElectronicProductOrderServiceImpl.class);

	public ElectronicProductOrderServiceImpl() {
		
	}
	
	public ElectronicProductOrderServiceImpl(ElectronicProductOrderRepository ordRepo, EMParser parser) {
		super();
		this.ordRepo = ordRepo;
		this.parser = new EMParser();
	}

	@Override
	public ElectronicProductOrderModel add(ElectronicProductOrderModel orderModel) throws ElectronicProductOrderNotFoundException {
		LOGGER.info("called add() method in ElectronicProduct");
		if (orderModel != null) {
				if (ordRepo.existsById(orderModel.getOrderId())) {
					throw new ElectronicProductOrderNotFoundException("Product with Id " +orderModel.getOrderId() + " is exist already");
				} 
				else {
					orderModel = parser.parse(ordRepo.save(parser.parse(orderModel)));
				}
			}
			return orderModel;
		}
	

	@Override
	public void deleteById(Long orderId) {
		LOGGER.info("called delete() method in ElectronicProduct");
		ordRepo.deleteById(orderId);
		
	}


	@Override
	public ElectronicProductOrderModel findById(Long orderId) {
		LOGGER.info("called FindById() method in ElectronicProduct");
		
		return parser.parse(ordRepo.findById(orderId).orElse(null));
	}


	@Override
	public List<ElectronicProductOrderModel> findAll() {
		LOGGER.info("called FindAll() method in ElectronicProduct");
		
		return ordRepo.findAll().stream().map(parser::parse).collect(Collectors.toList());
	}
	
	@Override
	public ElectronicProductOrderModel update(ElectronicProductOrderModel orderModel, Long orderId) throws ElectronicProductOrderNotFoundException {
		LOGGER.info("called Update() method in ElectronicProduct");
		
		if(orderModel != null) {
			if(!ordRepo.existsById(orderId)) {
				throw new ElectronicProductOrderNotFoundException("no such id");
			}
			orderModel = parser.parse(ordRepo.save(parser.parse(orderModel)));
			
		}
		return orderModel;
	}
	
	@Override
	public List<ElectronicProductOrderModel> findAllByCustomerId(Long customerId){
		LOGGER.info("called findAllById() method in ElectronicProduct");
		
		Optional<CustomerEntity> customerOptional = customerRepo.findById(customerId);	
		List<ElectronicProductOrderEntity> orders = customerOptional.get().getProductOrders();	
		return orders.stream().map(parser::parse).collect(Collectors.toList());
	}

}
