package com.cg.es.model;

public enum ProductType {
	LAPTOPS,MOBILES,TV,REFRIGIRATOR, AC, COMPUTER_ACCESSORIES,MOBILE_ACCESSORIES
	
}
