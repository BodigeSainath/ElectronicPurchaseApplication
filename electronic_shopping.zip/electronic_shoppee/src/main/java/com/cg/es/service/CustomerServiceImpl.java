package com.cg.es.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.es.entity.CustomerEntity;
import com.cg.es.exception.CustomerNotFoundException;
import com.cg.es.exception.ManagerNotFoundException;
import com.cg.es.model.CustomerModel;
import com.cg.es.model.ManagerModel;
import com.cg.es.repository.CustomerRepository;


@Service
public class CustomerServiceImpl implements ICustomerService {
	/*
	 * We are injecting dependencies of customer
	 */
	@Autowired
	private CustomerRepository custRepo;
	@Autowired
	private EMParser parser;
	static final Logger LOGGER = LoggerFactory.getLogger(CustomerServiceImpl.class);


	public CustomerServiceImpl() {

	}

	public CustomerServiceImpl(CustomerRepository custRepo, EMParser parser) {
		super();
		this.custRepo = custRepo;
		this.parser = new EMParser();
	}

	public CustomerRepository getCustRepo() {
		return custRepo;
	}

	public void setCustRepo(CustomerRepository custRepo) {
		this.custRepo = custRepo;
	}

	public EMParser getParser() {
		return parser;
	}

	public void setParser(EMParser parser) {
		this.parser = parser;
	}

	/*
	 * This method is to add a customer to the database
	 * 
	 */
	
	@Override
	public CustomerModel add(CustomerModel customerModel) throws CustomerNotFoundException {
		LOGGER.info("Called add() method of CustomerService");
		
		if (customerModel != null) {
			if (custRepo.existsById(customerModel.getCustomerId())) {
				throw new CustomerNotFoundException(
						"Customer with Id " + customerModel.getCustomerId() + " is exist already");
			} else if ((custRepo).existsByCustomerPhone(customerModel.getCustomerPhone())) {
				throw new CustomerNotFoundException(
						"Customer with mobile number " + customerModel.getCustomerPhone() + " is exist already");
			} else if (custRepo.existsByCustomerEmail(customerModel.getCustomerEmail())) {
				throw new CustomerNotFoundException(
						"Customer with email " + customerModel.getCustomerEmail() + " is exist already");
			} else {
				customerModel = parser.parse(custRepo.save(parser.parse(customerModel)));
			}
		}
		return customerModel;
	}

	/*
	 * This method is to update a customer in the database
	 */
	@Override
	public CustomerModel update(CustomerModel customerModel, Long customerId) throws CustomerNotFoundException {
		LOGGER.info("Called update() method of CustomerService");
		
		if (customerModel != null) {
			if (!custRepo.existsById(customerId)) {
				throw new CustomerNotFoundException("no such id");
			}
			customerModel = parser.parse(custRepo.save(parser.parse(customerModel)));
		}
		return customerModel;
	}

	/*
	 * This method is to delete a customer from the database
	 */
	@Override
	public void deleteById(Long customerId) {
		LOGGER.info("Called delete() method of CustomerService");
		
		custRepo.deleteById(customerId);

	}
	/*
	 * This method is to find a unique customer by Id
	 */
	@Override
	public CustomerModel findById(Long customerId) {
		LOGGER.info("Called findById() method of CustomerService");
		
		return parser.parse(custRepo.findById(customerId).orElse(null));
	}
	/*
	 *  This method is to find a customer through phone number
	 */
	@Override
	public boolean existsByCustomerPhone(String customerPhone) {
		return custRepo.existsByCustomerPhone(customerPhone);
	}
	/*
	 * This method is to find customer through customer Email Id
	 */
	@Override
	public boolean existsByCustomerEmail(String customerEmail) {
		return custRepo.existsByCustomerEmail(customerEmail);
	}
	/*
	 * This method is find list of a customer
	 */
	@Override
	public List<CustomerModel> findAll() {
		LOGGER.info("Called findAll() method of CustomerService");
		
		return custRepo.findAll().stream().map(parser::parse).collect(Collectors.toList());
	}

}