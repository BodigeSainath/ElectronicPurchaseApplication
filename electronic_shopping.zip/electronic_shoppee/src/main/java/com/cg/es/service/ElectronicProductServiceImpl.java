package com.cg.es.service;

import java.util.List;

import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.es.entity.CustomerEntity;
import com.cg.es.entity.ElectronicProductEntity;
import com.cg.es.entity.ElectronicProductOrderEntity;
import com.cg.es.exception.CustomerNotFoundException;
import com.cg.es.exception.ElectronicProductNotFoundException;
import com.cg.es.model.CustomerModel;
import com.cg.es.model.ElectronicProductModel;
import com.cg.es.model.ElectronicProductOrderModel;
import com.cg.es.model.ManagerModel;
import com.cg.es.repository.CustomerRepository;
import com.cg.es.repository.ElectronicProductRepository;

@Service
public class ElectronicProductServiceImpl implements IElectronicProductService{
	@Autowired				//inject dependency for ELectronicProduct
	private ElectronicProductRepository prodRepo;
	@Autowired					//inject dependency of customer
	private CustomerRepository customerRepo;
	@Autowired
	private EMParser parser;
	
	static final Logger LOGGER = LoggerFactory.getLogger(ElectronicProductServiceImpl.class);

	public ElectronicProductServiceImpl() {
		//no implementation
	}
	
	public ElectronicProductServiceImpl(ElectronicProductRepository prodRepo, EMParser parser) {
		super();
		this.prodRepo = prodRepo;
		this.parser = new EMParser();
	}
	

	@Override										//method for adding the electronicproduct	
	public ElectronicProductModel add(ElectronicProductModel electronicProductModel) throws ElectronicProductNotFoundException {
		LOGGER.info("called add() method in ElectronicProduct");
			if (electronicProductModel != null) {
				if (prodRepo.existsById(electronicProductModel.getProductId())) {
					throw new ElectronicProductNotFoundException("Product with Id " +electronicProductModel.getProductId() + " is exist already");
				} 
				else {
					electronicProductModel = parser.parse(prodRepo.save(parser.parse(electronicProductModel)));
				}
			}
			return electronicProductModel;
		}
	
	@Override							//method for updating the electronicProductModel
	public ElectronicProductModel update(ElectronicProductModel electronicProductModel, Long productId) throws ElectronicProductNotFoundException {
		LOGGER.info("called update() method in ElectronicProduct");
		
		if(electronicProductModel != null) {
			if(!prodRepo.existsById(productId)) {
				throw new ElectronicProductNotFoundException("no such id");
				}
			electronicProductModel = parser.parse(prodRepo.save(parser.parse(electronicProductModel)));
			}
		return electronicProductModel;
		}

	
	@Override										//method for deleting product by Id
	public void deleteById(Long productId) {
		LOGGER.info("called delete() method in ElectronicProduct");
		
		prodRepo.deleteById(productId);
		
	}


	@Override									//method for finding product by Id
	public ElectronicProductModel findById(Long productId) {
		LOGGER.info("called findById() method in ElectronicProduct");
		
		return parser.parse(prodRepo.findById(productId).orElse(null));
	}


	@Override									//method for finding All
	public List<ElectronicProductModel> findAll() {
		LOGGER.info("called FindAll() method in ElectronicProduct");
		return prodRepo.findAll().stream().map(parser::parse).collect(Collectors.toList());
	}
	
	@Override							//method for finding customer by Id
	public List<ElectronicProductModel> findAllByCustomerId(Long customerId){
		Optional<CustomerEntity> customerOptional = customerRepo.findById(customerId);	
		List<ElectronicProductEntity> products = customerOptional.get().getElecproduct();	
		return products.stream().map(parser::parse).collect(Collectors.toList());
	}


}
