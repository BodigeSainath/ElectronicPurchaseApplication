package com.cg.es.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.es.entity.CustomerEntity;
import com.cg.es.entity.ElectronicProductEntity;
import com.cg.es.entity.ElectronicProductOrderEntity;
import com.cg.es.entity.Manager;
import com.cg.es.exception.ManagerNotFoundException;
import com.cg.es.model.CustomerModel;
import com.cg.es.model.ElectronicProductModel;
import com.cg.es.model.ElectronicProductOrderModel;
import com.cg.es.model.ManagerModel;
import com.cg.es.repository.CustomerRepository;
import com.cg.es.repository.ElectronicProductOrderRepository;
import com.cg.es.repository.ElectronicProductRepository;
import com.cg.es.repository.ManagerRepository;

@Service
public class ManagerServiceImpl implements IManagerService {
	@Autowired 								// inject dependency for manager
	private ManagerRepository managerRepo;
	@Autowired 											// inject dependency for customer
	private CustomerRepository customerRepo;
	@Autowired 								// inject dependency for ELectronicProduct
	private ElectronicProductRepository elecprodRepo;
	@Autowired			
	private ElectronicProductOrderRepository elecprodorderRepo;

	@Autowired
	private EMParser parser;
	static final Logger LOGGER = LoggerFactory.getLogger(ManagerServiceImpl.class);

	public ManagerServiceImpl() {
		super();
	}

	public ManagerServiceImpl(ManagerRepository managerRepo, EMParser parser) {
		super();
		this.managerRepo = managerRepo;
		this.parser = new EMParser();
	}

	@Override							//method for adding a manager 
	public ManagerModel add(ManagerModel managerModel) throws ManagerNotFoundException {
		LOGGER.info("called add() method of manager");
		if (managerModel != null) {
			if (managerRepo.existsById(managerModel.getManagerId())) {
				throw new ManagerNotFoundException(
						"Manager with Id " + managerModel.getManagerId() + " is exist already");
			} else {
				managerModel = parser.parse(managerRepo.save((parser.parse(managerModel))));
			}
		}
		return managerModel;
	}

	@Override								//method for updating manager by id
	public ManagerModel update(ManagerModel managerModel, Long managerId) throws ManagerNotFoundException {
		LOGGER.info("called update() method of manager");
		if (managerModel != null) {
			if (!managerRepo.existsById(managerId)) {
				throw new ManagerNotFoundException("no such id");
			}
			managerModel = parser.parse(managerRepo.save(parser.parse(managerModel)));
		}
		return managerModel;
	}

	@Override						//method for deleting manager by id
	public void deleteById(Long managerId) {
		LOGGER.info("called delete() method of manager");

		managerRepo.deleteById(managerId);
	}

	@Override								//method for finding by Id
	public ManagerModel findById(Long managerId) {
		LOGGER.info("called FindById() method of manager");

		return parser.parse(managerRepo.findById(managerId).orElse(null));
	}

	@Override								//method for finding all manager
	public List<ManagerModel> findAll() {
		LOGGER.info("called findAll() method of manager");

		return managerRepo.findAll().stream().map(parser::parse).collect(Collectors.toList());
	}

	@Override						//method for getting manager by Id
	public List<CustomerModel> getAllByManagerId(Long managerId) {
		LOGGER.info("called getById() method of manager");

		Optional<Manager> customerOptional = managerRepo.findById(managerId);
		List<CustomerEntity> customers = customerOptional.get().getCustomers();
		return customers.stream().map(parser::parse).collect(Collectors.toList());
	}

	@Override								//method for display manager by id
	public List<ElectronicProductModel> showAllByManagerId(Long managerId) {
		LOGGER.info("called show() method of manager");
		Optional<Manager> productOptional = managerRepo.findById(managerId);
		List<ElectronicProductEntity> products = productOptional.get().getElectronicProducts();
		return products.stream().map(parser::parse).collect(Collectors.toList());
	}

	@Override									//Method for finding all manager by Id
	public List<ElectronicProductOrderModel> findAllByManagerId(Long managerId) {
		Optional<Manager> orderOptional = managerRepo.findById(managerId);
		List<ElectronicProductOrderEntity> orders = orderOptional.get().getProductOrders();
		return orders.stream().map(parser::parse).collect(Collectors.toList());
	}

}